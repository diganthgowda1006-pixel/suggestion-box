import secrets
from io import BytesIO
from pathlib import Path
import warnings
from uuid import uuid4

from flask import Blueprint, current_app, flash, redirect, render_template, request, session, url_for
from PIL import Image, UnidentifiedImageError
from sqlalchemy.exc import SQLAlchemyError

from app.extensions import db, limiter
from app.forms import SubmissionForm
from app.i18n import SUPPORTED_LANGUAGES, translate
from app.models import StatusUpdate, Submission
from app.services.ai_assist import detect_priority, suggest_category


public = Blueprint("public", __name__)

SUPPORTED_IMAGE_FORMATS = {
    ".jpg": ("JPEG", ".jpg"),
    ".jpeg": ("JPEG", ".jpg"),
    ".png": ("PNG", ".png"),
    ".gif": ("GIF", ".gif"),
    ".webp": ("WEBP", ".webp"),
}
MAX_IMAGE_PIXELS = 20_000_000


def _read_optional_photo(form):
    photo = form.photo.data
    if photo is None or not photo.filename:
        return None

    extension = Path(photo.filename).suffix.lower()
    expected_format = SUPPORTED_IMAGE_FORMATS.get(extension)
    image_data = photo.read()
    error_message = (
        "Photo must be a valid JPEG, PNG, GIF, or WebP image under "
        "5 MB and 20 megapixels."
    )
    if expected_format is None:
        form.photo.errors.append(error_message)
        return None

    expected_image_format, output_extension = expected_format
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(image_data)) as image:
                if image.format != expected_image_format:
                    raise ValueError("File extension and image format do not match.")
                if image.width * image.height > MAX_IMAGE_PIXELS:
                    raise ValueError("Image exceeds the pixel limit.")
                image.verify()

            with Image.open(BytesIO(image_data)) as image:
                if image.width * image.height > MAX_IMAGE_PIXELS:
                    raise ValueError("Image exceeds the pixel limit.")
                image.seek(0)
                image.load()
                if image.format == "JPEG" and image.mode not in ("RGB", "L"):
                    image = image.convert("RGB")

                normalized = BytesIO()
                image.save(normalized, format=expected_image_format)
                normalized_data = normalized.getvalue()
                if len(normalized_data) > current_app.config["MAX_CONTENT_LENGTH"]:
                    raise ValueError("Normalized image exceeds the upload limit.")
    except (
        Image.DecompressionBombError,
        Image.DecompressionBombWarning,
        UnidentifiedImageError,
        OSError,
        ValueError,
    ):
        form.photo.errors.append(error_message)
        return None

    return normalized_data, output_extension


def _new_tracking_code():
    return f"DGB-{secrets.token_hex(8).upper()}"


@public.route("/", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def submit_suggestion():
    form = SubmissionForm()

    if form.validate_on_submit():
        photo_data = _read_optional_photo(form)
        if form.photo.errors:
            return render_template("submit.html", form=form), 400

        tracking_code = _new_tracking_code()
        while db.session.query(Submission.id).filter_by(
            tracking_code=tracking_code
        ).first():
            tracking_code = _new_tracking_code()

        photo_filename = None
        saved_photo = None
        if photo_data is not None:
            image_data, extension = photo_data
            photo_filename = f"{uuid4().hex}{extension}"
            saved_photo = Path(current_app.config["UPLOAD_FOLDER"]) / photo_filename
            try:
                saved_photo.write_bytes(image_data)
            except OSError:
                current_app.logger.exception("Could not save an uploaded suggestion photo.")
                flash(translate("We could not save the photo. Please try again without it."), "danger")
                return render_template("submit.html", form=form), 500

        submission = Submission(
            tracking_code=tracking_code,
            category=form.category.data,
            suggested_category=suggest_category(form.description.data),
            priority=detect_priority(form.description.data),
            description=form.description.data.strip(),
            location=form.location.data.strip(),
            is_anonymous=form.is_anonymous.data,
            photo_filename=photo_filename,
        )
        submission.status_updates.append(
            StatusUpdate(
                status="Received",
                remarks=translate("Your suggestion has been received."),
                is_public=True,
            )
        )
        db.session.add(submission)

        try:
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            if saved_photo is not None:
                saved_photo.unlink(missing_ok=True)
            current_app.logger.exception("Could not save a citizen suggestion.")
            flash(translate("We could not submit your suggestion. Please try again."), "danger")
            return render_template("submit.html", form=form), 500

        return redirect(url_for("public.submitted", tracking_code=tracking_code))

    return render_template("submit.html", form=form)


@public.route("/language", methods=["POST"])
def set_language():
    language = request.form.get("language", "")
    if language not in SUPPORTED_LANGUAGES:
        flash(translate("Please choose English or Kannada."), "warning")
        return redirect(url_for("public.submit_suggestion"))

    session["language"] = language
    referrer = request.referrer
    if referrer:
        from urllib.parse import urlsplit

        parsed_referrer = urlsplit(referrer)
        if parsed_referrer.netloc == request.host and parsed_referrer.scheme in ("http", "https"):
            return redirect(referrer)
        if not parsed_referrer.netloc and parsed_referrer.path.startswith("/"):
            return redirect(parsed_referrer.path)

    return redirect(url_for("public.submit_suggestion"))


@public.route("/submitted/<tracking_code>")
def submitted(tracking_code):
    submission = Submission.query.filter_by(tracking_code=tracking_code).first_or_404()
    return render_template("submitted.html", submission=submission)


@public.route("/track")
def track_suggestion():
    raw_tracking_code = request.args.get("tracking_code", "")
    tracking_code = raw_tracking_code.strip().upper()
    submission = None
    status_updates = []
    not_found = False

    if raw_tracking_code:
        if len(tracking_code) <= 32:
            submission = Submission.query.filter_by(
                tracking_code=tracking_code
            ).first()
        not_found = submission is None

    if submission is not None:
        status_updates = (
            StatusUpdate.query.filter_by(
                submission_id=submission.id,
                is_public=True,
            )
            .order_by(StatusUpdate.created_at.asc(), StatusUpdate.id.asc())
            .all()
        )

    return render_template(
        "track.html",
        tracking_code=tracking_code,
        submission=submission,
        status_updates=status_updates,
        not_found=not_found,
    )
