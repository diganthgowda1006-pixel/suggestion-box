from datetime import datetime, timedelta, timezone
from functools import wraps
from urllib.parse import urlsplit

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from werkzeug.security import check_password_hash

from app.extensions import db, limiter
from app.forms import StaffLoginForm, StatusUpdateForm
from app.i18n import current_language, translate
from app.models import CATEGORIES, STATUSES, StaffUser, StatusUpdate, Submission, utc_now
from app.services.ai_assist import find_similar_submissions, weekly_issue_summary


admin = Blueprint("admin", __name__)


def staff_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        staff_user_id = session.get("staff_user_id")
        staff_user = db.session.get(StaffUser, staff_user_id) if staff_user_id else None
        if staff_user is None:
            session.clear()
            return redirect(url_for("admin.login", next=request.full_path))

        return view(*args, **kwargs)

    return wrapped_view


@admin.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def login():
    if session.get("staff_user_id"):
        return redirect(url_for("admin.submission_list"))

    form = StaffLoginForm()
    if form.validate_on_submit():
        username = form.username.data.strip()
        staff_user = StaffUser.query.filter_by(username=username).first()
        if staff_user is None or not check_password_hash(
            staff_user.password_hash,
            form.password.data,
        ):
            flash(translate("Username or password is incorrect."), "danger")
        else:
            csrf_session_key = current_app.config.get(
                "WTF_CSRF_FIELD_NAME",
                "csrf_token",
            )
            csrf_session_token = session.get(csrf_session_key)
            language = current_language()
            session.clear()
            if csrf_session_token is not None:
                session[csrf_session_key] = csrf_session_token
            session["language"] = language
            session["staff_user_id"] = staff_user.id
            session.permanent = True
            destination = request.args.get("next", "")
            parsed_destination = urlsplit(destination)
            if (
                not parsed_destination.path.startswith("/")
                or parsed_destination.path.startswith("//")
                or parsed_destination.scheme
                or parsed_destination.netloc
                or "\\" in destination
            ):
                destination = url_for("admin.submission_list")
            return redirect(destination)

    return render_template("admin/login.html", form=form)


@admin.route("/logout", methods=["POST"])
@staff_required
def logout():
    language = current_language()
    session.clear()
    session["language"] = language
    flash(translate("You have been signed out."), "success")
    return redirect(url_for("admin.login"))


@admin.route("/")
@staff_required
def submission_list():
    selected_status = request.args.get("status", "")
    selected_category = request.args.get("category", "")
    search_text = request.args.get("q", "").strip()

    query = Submission.query
    if selected_status in STATUSES:
        query = query.filter(Submission.status == selected_status)
    else:
        selected_status = ""
    if selected_category in CATEGORIES:
        query = query.filter(Submission.category == selected_category)
    else:
        selected_category = ""
    if search_text:
        search_pattern = f"%{search_text}%"
        query = query.filter(
            or_(
                Submission.tracking_code.ilike(search_pattern),
                Submission.description.ilike(search_pattern),
                Submission.location.ilike(search_pattern),
            )
        )

    submissions = query.order_by(Submission.created_at.desc()).all()
    return render_template(
        "admin/submissions.html",
        submissions=submissions,
        statuses=STATUSES,
        categories=CATEGORIES,
        selected_status=selected_status,
        selected_category=selected_category,
        search_text=search_text,
    )


@admin.route("/dashboard")
@staff_required
def dashboard():
    category_totals = dict(
        db.session.query(Submission.category, db.func.count(Submission.id))
        .group_by(Submission.category)
        .all()
    )
    status_totals = dict(
        db.session.query(Submission.status, db.func.count(Submission.id))
        .group_by(Submission.status)
        .all()
    )

    today = datetime.now(timezone.utc).date()
    first_day = today - timedelta(days=6)
    trend_labels = [
        (first_day + timedelta(days=offset)).isoformat()
        for offset in range(7)
    ]
    trend_totals = {label: 0 for label in trend_labels}
    recent_submissions = (
        Submission.query.with_entities(Submission.created_at)
        .filter(Submission.created_at >= datetime.combine(
            first_day, datetime.min.time(), tzinfo=timezone.utc
        ))
        .all()
    )
    for (created_at,) in recent_submissions:
        day = created_at.date().isoformat()
        if day in trend_totals:
            trend_totals[day] += 1

    weekly_submissions = Submission.query.filter(
        Submission.created_at
        >= datetime.combine(first_day, datetime.min.time(), tzinfo=timezone.utc)
    ).all()
    weekly_summary = weekly_issue_summary(weekly_submissions)

    resolved_times = (
        db.session.query(Submission.created_at, Submission.resolved_at)
        .filter(
            Submission.status == "Resolved",
            Submission.resolved_at.isnot(None),
        )
        .all()
    )
    resolution_seconds = []
    for created_at, resolved_at in resolved_times:
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        if resolved_at.tzinfo is None:
            resolved_at = resolved_at.replace(tzinfo=timezone.utc)
        duration_seconds = (resolved_at - created_at).total_seconds()
        if duration_seconds >= 0:
            resolution_seconds.append(duration_seconds)

    average_resolution_hours = (
        sum(resolution_seconds) / len(resolution_seconds) / 3600
        if resolution_seconds
        else None
    )

    return render_template(
        "admin/dashboard.html",
        categories=CATEGORIES,
        category_labels=[
            translate(category.replace("_", " ").title())
            for category in CATEGORIES
        ],
        statuses=STATUSES,
        category_totals=category_totals,
        category_values=[category_totals.get(category, 0) for category in CATEGORIES],
        status_totals=status_totals,
        trend_labels=trend_labels,
        trend_values=[trend_totals[label] for label in trend_labels],
        average_resolution_hours=average_resolution_hours,
        weekly_summary=weekly_summary,
    )


@admin.route("/submissions/<int:submission_id>", methods=["GET", "POST"])
@staff_required
def edit_submission(submission_id):
    submission = db.session.get(Submission, submission_id)
    if submission is None:
        abort(404)

    form = StatusUpdateForm()
    if request.method == "GET":
        form.status.data = submission.status

    if form.validate_on_submit():
        staff_user = db.session.get(StaffUser, session["staff_user_id"])
        if staff_user is None:
            session.clear()
            return redirect(url_for("admin.login"))

        new_status = form.status.data
        updated_at = utc_now()
        submission.status = new_status
        submission.updated_at = updated_at
        submission.resolved_at = (
            updated_at if new_status == "Resolved" else None
        )

        submission.status_updates.append(
            StatusUpdate(
                staff_user=staff_user,
                status=new_status,
                remarks=form.remarks.data or None,
                is_public=form.is_public.data,
                created_at=updated_at,
            )
        )
        try:
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            current_app.logger.exception(
                "Could not update submission %s.",
                submission_id,
            )
            flash(translate("The update could not be saved. Please try again."), "danger")
            return render_template(
                "admin/edit_submission.html",
                submission=submission,
                form=form,
            ), 500

        flash(translate("Suggestion status and remarks were updated."), "success")
        return redirect(url_for("admin.edit_submission", submission_id=submission.id))

    return render_template(
        "admin/edit_submission.html",
        submission=submission,
        form=form,
        similar_submissions=find_similar_submissions(submission),
    )
