import re
from collections import Counter
from difflib import SequenceMatcher

from app.models import CATEGORIES, Submission


CATEGORY_KEYWORDS = {
    "roads": (
        "road",
        "street",
        "pothole",
        "footpath",
        "bridge",
        "ರಸ್ತೆ",
        "ಗುಂಡಿ",
        "ಸೇತುವೆ",
    ),
    "water": (
        "water",
        "pipe",
        "leak",
        "tap",
        "drinking water",
        "ನೀರು",
        "ಕುಡಿಯುವ ನೀರು",
        "ಸೋರಿಕೆ",
    ),
    "electricity": (
        "electricity",
        "power cut",
        "street light",
        "transformer",
        "wire",
        "ವಿದ್ಯುತ್",
        "ವಿದ್ಯುತ್ ಕಡಿತ",
        "ಬೀದಿ ದೀಪ",
        "ತಂತಿ",
    ),
    "sanitation": (
        "garbage",
        "drain",
        "sewage",
        "toilet",
        "waste",
        "ಕಸ",
        "ಚರಂಡಿ",
        "ತ್ಯಾಜ್ಯ",
        "ಶೌಚಾಲಯ",
    ),
}

URGENT_KEYWORDS = (
    "urgent",
    "emergency",
    "danger",
    "dangerous",
    "unsafe",
    "immediately",
    "fire",
    "accident",
    "ತುರ್ತು",
    "ಅಪಾಯ",
    "ಅಪಾಯಕಾರಿ",
    "ತಕ್ಷಣ",
    "ಬೆಂಕಿ",
)


def _normalized_text(text):
    return " ".join(text.lower().split())


def _contains_keyword(text, keyword):
    if any(ord(character) > 127 for character in keyword):
        return keyword in text
    return re.search(rf"(?<!\w){re.escape(keyword)}(?!\w)", text) is not None


def suggest_category(description):
    """Return a locally inferred category, or None when keywords are unclear."""
    normalized = _normalized_text(description)
    scores = {
        category: sum(
            1
            for keyword in keywords
            if _contains_keyword(normalized, keyword)
        )
        for category, keywords in CATEGORY_KEYWORDS.items()
    }
    highest_score = max(scores.values(), default=0)
    if highest_score == 0:
        return None

    top_categories = [
        category for category, score in scores.items() if score == highest_score
    ]
    return top_categories[0] if len(top_categories) == 1 else None


def detect_priority(description):
    normalized = _normalized_text(description)
    if any(_contains_keyword(normalized, keyword) for keyword in URGENT_KEYWORDS):
        return "urgent"
    return "normal"


def _similarity(left, right):
    left_normalized = _normalized_text(left)
    right_normalized = _normalized_text(right)
    if not left_normalized or not right_normalized:
        return 0.0
    if left_normalized == right_normalized:
        return 1.0

    left_words = set(re.findall(r"\w+", left_normalized))
    right_words = set(re.findall(r"\w+", right_normalized))
    combined_words = left_words | right_words
    word_overlap = len(left_words & right_words) / len(combined_words)
    character_similarity = SequenceMatcher(
        None,
        left_normalized,
        right_normalized,
    ).ratio()
    return max(word_overlap, character_similarity)


def find_similar_submissions(submission, limit=5):
    candidates = (
        Submission.query.filter(Submission.id != submission.id)
        .order_by(Submission.created_at.desc())
        .all()
    )
    similar = []
    for candidate in candidates:
        score = _similarity(submission.description, candidate.description)
        if score >= 0.45:
            similar.append((score, candidate))

    similar.sort(key=lambda result: result[0], reverse=True)
    return [
        {"submission": candidate, "similarity_percent": round(score * 100)}
        for score, candidate in similar[:limit]
    ]


def weekly_issue_summary(submissions):
    """Summarize weekly counts without extracting or repeating free-text reports."""
    category_counts = Counter(
        submission.category for submission in submissions
    )
    location_counts = Counter(
        submission.location.strip()
        for submission in submissions
        if submission.location.strip()
    )
    top_category = (
        category_counts.most_common(1)[0][0]
        if category_counts
        else None
    )
    top_location = (
        location_counts.most_common(1)[0][0]
        if location_counts
        else None
    )
    urgent_count = sum(
        submission.priority == "urgent" for submission in submissions
    )
    return {
        "total": len(submissions),
        "top_category": top_category,
        "top_location": top_location,
        "urgent_count": urgent_count,
    }
